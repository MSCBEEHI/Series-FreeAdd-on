import { world } from '@minecraft/server'
import "./WatchdogTerminate/bug"
//© MSC BEEHI
function GamemodeChanger() {
   world.events.beforeChat.subscribe((eventData) => {
       var Player = eventData.sender.name
       switch (eventData.message) {
           case '!tmn10': 
               world.getDimension('overworld').runCommand(`execute ${Player} ~ ~ ~ tag @s add m10`)
	       eventData.cancel = true
           break;
           case '!tmn100':
               world.getDimension('overworld').runCommand(`execute ${Player} ~ ~ ~ tag @s add m100`)
	       eventData.cancel = true
           break;
           case '!tmn1000':
               world.getDimension('overworld').runCommand(`execute ${Player} ~ ~ ~ tag @s add m1000`)
	       eventData.cancel = true
           break;
           case '!tmn10000':
               world.getDimension('overworld').runCommand(`execute ${Player} ~ ~ ~ tag @s add m10000`)
	       eventData.cancel = true
           break;
           case '!tmn100000':
               world.getDimension('overworld').runCommand(`execute ${Player} ~ ~ ~ tag @s add m100000`)
	       eventData.cancel = true
           break;
           case '!help':
               world.getDimension('overworld').runCommand(`execute ${Player} ~ ~ ~ tag @s add help`)
	       eventData.cancel = true
           break;
       }
   })
 }
 //© MSC BEEHI
GamemodeChanger()