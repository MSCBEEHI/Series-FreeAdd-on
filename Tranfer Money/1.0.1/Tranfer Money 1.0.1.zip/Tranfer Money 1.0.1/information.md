[EN]
© Copyright MSC BEEHI [transfer]

This system is not allowed to modify and this system was created by myself. This system is a money transfer with 5 commands or keys :

- !tmn10
- !tmn100
- !tmn1000
- !tmn10000
- !tmn100000
- !help

## Support
YouTube -[https://youtube.com/channel/UCocD1zoatTqv197-3ZdUoZw]
Discord -[https://discord.gg/MEtNcR2NQt]

[TH]
© ลิขสิทธิ์ MSC BEEHI [โอน]

ระบบนี้ไม่ได้รับอนุญาตให้แก้ไข และระบบนี้สร้างขึ้นโดยผมเอง ระบบนี้เป็นการโอนเงินด้วย 5 คำสั่งหรือคีย์ :

- !tmn10
- !tmn100
- !tmn1000
- !tmn10000
- !tmn100000
- !help

## สนับสนุน
ยูทูบ -[https://youtube.com/channel/UCocD1zoatTqv197-3ZdUoZw]
ดิสคอต -[https://discord.gg/MEtNcR2NQt]