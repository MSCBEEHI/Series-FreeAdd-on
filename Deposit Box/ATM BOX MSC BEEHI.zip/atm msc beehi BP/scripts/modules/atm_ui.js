//©MSC BEEHI This system is made to distribute to people who want the system. But those who fix the credit let it sink.

import { world } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
function getScore(objective, target, useZero = true) {
    try {
        const obj = world.scoreboard.getObjective(objective)
        if (typeof target == 'string') {
            return obj.getScore(obj.getParticipants().find(v => v.displayName == target))
        }
        return obj.getScore(target.scoreboard)
    } catch {
        return useZero ? 0 : NaN
    }
}

world.events.entityHit.subscribe(eventData => {
    var player = eventData.entity
    if(eventData.hitEntity.id === "atm:cupboard"){
        openui1(player)
    }
})

function openui1(player){
    let form = new ActionFormData()
    .title('Menu Money')
    .body('กรุณาเลือกรายการของคุณ')
    .button('ฝากเงิน', 'textures/ui/atm1.png')
    .button('ถอนเงิน', 'textures/ui/atm2.png')
    form.show(player).then((result => {
        if(result.selection == 0){
            openui2(player)
        }
        if(result.selection == 1){
            openui3(player)
        }
    }))
}

function openui2(player){
    let money = getScore("money", player, true)
    let deposit = getScore("deposit", player, true)
    let modal = new ModalFormData()
    .title('ฝากเงิน')
    .slider(`§2§lจำนวนเงินที่มี§r ${money} \n§c§lจำนวนเงินที่ฝาก§r ${deposit}\nจำนวนเงินที่ต้องการฝาก`, 0, money, 100)
    modal.show(player).then(result => {
            player.runCommand(`scoreboard players remove @s[scores={money=${result.formValues[0]}..}] money ${result.formValues[0]}`)
            player.runCommand(`scoreboard players add @s deposit ${result.formValues[0]}`)
            player.runCommand(`tellraw @s {"rawtext":[{"text":"คุณได้ฝากเงินจำนวน §e${result.formValues[0]}§r"}]}`)
    })
}

function openui3(player){
    let money = getScore("money", player, true)
    let deposit = getScore("deposit", player, true)
    let modal = new ModalFormData()
    .title('ถอนเงิน')
    .slider(`§2§lจำนวนเงินที่มี§r ${money} \n§c§lจำนวนเงินที่ฝาก§r ${deposit} \nจำนวนเงินที่ต้องการถอน`, 0, deposit, 100)
    modal.show(player).then(result => {
            player.runCommand(`scoreboard players remove @s[scores={deposit=${result.formValues[0]}..}] deposit ${result.formValues[0]}`)
            player.runCommand(`scoreboard players add @s money ${result.formValues[0]}`)
            player.runCommand(`tellraw @s {"rawtext":[{"text":"คุณได้ถอนเงินจำนวน §e${result.formValues[0]}§r"}]}`)
    })
}

/**
 * @author MSC BEEHI
 * @description This Script was created by MSC BEEHI
 * @copyright 2021-2022 MSCBEEHI
 * @youtube https://youtube.com/c/MSCBEEHI
 * @discordServer https://bit.ly/3szUBmK
 */