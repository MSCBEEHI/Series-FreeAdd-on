import { world } from "@minecraft/server"

let CommandsPrefiexl = '!!'

world.events.beforeChat.subscribe((eventData) => {
    let player = eventData.sender
    let msg = eventData.message
    if (msg.split(" ")[0] == `${CommandsPrefiexl}1234`) {
        eventData.cancel = true
        player.runCommand(`execute "${player.name}" ~~~ tp 0 200 0`)
    } else if (msg.split(" ")[0] == `${CommandsPrefiexl}help`) {
        eventData.cancel = true
        player.tell(`§7- !!password: §ain Discord\\n§7§r`)
    } else {
        eventData.cancel = true
        player.tell(`§cCustom command not found! Please type §7${CommandsPrefiexl}help §cfor a list of all avalible commands§r`)
    }
})